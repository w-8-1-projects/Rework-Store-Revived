@echo off 
title instller(v0.1 standalone)MadeByWindowslock
mkdir c:\apps\
goto nnkw
:mink
echo go to the start screen and see if app is installed if not try again
pause
exit
:cmk2
cd %APPXD%
ren %APPXN%.appx %APPXN%.zip
cls
goto 556knA

:nnkw
cls
echo =====================
echo   WindowsLock 2026
echo windows RT 8.1 metro 
echo    app installer
echo =====================
echo.
echo insert Appx file directory (c:\......\....\):
set /p APPXD=

cls
goto nnkla
:77hha
cd c:\apps\%APPXN%
del AppxSignature.p7x
cls
goto mmkad
:mmk2
echo =====================
echo   WindowsLock 2026
echo windows RT 8.1 metro 
echo    app installer
echo =====================
echo.
echo insert your Windows RT 7zip directory 
echo (c:\.....\....\ [ (don't write ...\7zip.exe)):
set /p SZIP=
cls
goto cmk2

:556knA
%SZIP%\7z.exe x "%APPXD%\%APPXN%.zip" -o"C:\apps\%APPXN%"
ren %APPXN%.zip %APPXN%.appx
cls
goto 77hha
:mmkad
powershell add-appxpackage -register AppxManifest.xml
cls
goto mink
:nnkla
echo =====================
echo   WindowsLock 2026
echo windows RT 8.1 metro 
echo    app installer
echo =====================
echo.
echo insert Appx full name (without extension *.appx):
set /p APPXN=
cls
goto mmk2







